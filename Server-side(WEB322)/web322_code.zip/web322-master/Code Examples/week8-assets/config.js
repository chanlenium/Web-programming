module.exports = {
  database_connection_string: ""
}